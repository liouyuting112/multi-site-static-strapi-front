<?php
/**
 * Theme header
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
    <div class="scanlines"></div>
    
    <header>
        <div class="container header-inner">
            <div class="logo">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                    懷舊<span>時光機</span>
                </a>
            </div>
            <button class="menu-toggle" aria-label="Toggle navigation">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <nav class="nav-menu">
                <?php
                // 導覽選單：預設使用靜態結構，之後可改成 wp_nav_menu
                ?>
                <ul>
                    <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="active">首頁</a></li>
                    <li class="dropdown">
                        <a href="#">收藏指南 ▾</a>
                        <ul class="dropdown-menu">
                            <li><a href="#fixed-1">卡帶保養術</a></li>
                            <li><a href="#fixed-2">新手收藏指南</a></li>
                            <li><a href="#fixed-3">老遊戲的魅力</a></li>
                        </ul>
                    </li>
                    <li><a href="#daily">每日精選文章</a></li>
                    <li><a href="#about">關於我們</a></li>
                    <li><a href="#contact">聯絡我們</a></li>
                </ul>
            </nav>
        </div>
    </header>


