<?php
/**
 * Multi Gaming Sites Theme functions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 基本支援
add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );

// 註冊導覽選單（之後可以在 WP 後台指定）
function mgs_register_menus() {
	register_nav_menus(
		array(
			'primary' => __( '主選單（Site1 導覽）', 'multi-gaming-sites' ),
		)
	);
}
add_action( 'after_setup_theme', 'mgs_register_menus' );

// 載入樣式與腳本
function mgs_enqueue_assets() {
	$theme_version = wp_get_theme()->get( 'Version' );

	// 佈景主題主要樣式（已包含 site1 的 CSS）
	wp_enqueue_style(
		'mgs-style',
		get_stylesheet_uri(),
		array(),
		$theme_version
	);

	// site1 導覽用 JS（從原本 site1/js/main.js 搬過來）
	wp_enqueue_script(
		'mgs-site1-main',
		get_template_directory_uri() . '/js/site1-main.js',
		array(),
		$theme_version,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'mgs_enqueue_assets' );


