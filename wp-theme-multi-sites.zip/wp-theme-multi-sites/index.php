<?php
/**
 * 必要的預設樣板：一般情況首頁會用 front-page.php，
 * 但 WordPress 規定主題至少要有一個 index.php。
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main class="container">
	<?php if ( have_posts() ) : ?>
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<article <?php post_class(); ?>>
				<h1><?php the_title(); ?></h1>
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</article>
		<?php endwhile; ?>
	<?php else : ?>
		<p>目前沒有內容可以顯示。</p>
	<?php endif; ?>
</main>

<?php
get_footer();


