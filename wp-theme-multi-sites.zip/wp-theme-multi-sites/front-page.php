<?php
/**
 * 首頁樣板：以 site1/index.html 為基礎
 * 之後可以改成用 WP_Query 撈分類為 site1 的文章
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<div class="container layout-grid">
	<!-- Main Content Column -->
	<main>
		<!-- Hero -->
		<section class="retro-hero">
			<div class="hero-text">
				<h1>INSERT COIN<br>TO START</h1>
				<p>這裡沒有 4K 畫質，只有滿滿的回憶。吹一下卡帶，我們重新開始冒險。</p>
			</div>
			<div class="hero-visual">
				<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-hero.webp?raw=true" alt="一台舊式CRT電視機連接著紅白機，畫面上是像素風格的遊戲畫面，光線溫暖" loading="lazy">
			</div>
		</section>

		<!-- Manual Update (Fixed) -->
		<section class="featured-posts">
			<h2 class="pixel-title">精選攻略</h2>

			<article class="post-entry" id="fixed-1">
				<a href="#">
					<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-fixed2.webp?raw=true" alt="清潔卡帶示意圖" loading="lazy">
					<div class="post-content">
						<h3>卡帶接觸不良？千萬別用吹的！</h3>
						<p>這大概是我們童年最大的集體錯誤記憶。用口水吹卡帶雖然暫時有用，但長期下來只會讓金屬接點鏽蝕得更嚴重。</p>
						<span class="read-btn">READ MORE >></span>
					</div>
				</a>
			</article>

			<article class="post-entry" id="fixed-2">
				<a href="#">
					<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-fixed3.webp?raw=true" alt="收藏櫃示意圖" loading="lazy">
					<div class="post-content">
						<h3>新手收藏家的第一堂課</h3>
						<p>想入坑懷舊遊戲收藏？先別急著買。從分辨盜版卡帶到保存環境的濕度控制，這些學費你不必繳。</p>
						<span class="read-btn">READ MORE >></span>
					</div>
				</a>
			</article>

			<article class="post-entry" id="fixed-3">
				<a href="#">
					<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-fixed1.webp?raw=true" alt="左邊是像素遊戲畫面，右邊是現代3D高畫質遊戲畫面，形成強烈對比" loading="lazy">
					<div class="post-content">
						<h3>為什麼我們還在玩 8-bit 遊戲？</h3>
						<p>在 3A 大作畫面越來越擬真的今天，為什麼那些「方塊人」依然能讓我們感動？探討像素藝術的獨特美學。</p>
						<span class="read-btn">READ MORE >></span>
					</div>
				</a>
			</article>
		</section>
	</main>

	<!-- Sidebar Column (Daily) -->
	<aside id="daily">
		<section class="daily-widget">
			<h2 class="pixel-title small">每日精選</h2>
			<ul class="widget-list">
				<?php
				/**
				 * 這裡示範：如果你之後在後台建立分類「site1」+「daily」
				 * 就可以改用 WP_Query 撈最新三篇每日文章。
				 *
				 * 目前先判斷：如果有符合的文章，就顯示動態；否則 fallback 回靜態內容。
				 */

				$daily_query = new WP_Query(
					array(
						'posts_per_page' => 3,
						'category_name'  => 'site1+daily',
					)
				);

				if ( $daily_query->have_posts() ) :
					while ( $daily_query->have_posts() ) :
						$daily_query->the_post();
						?>
						<li>
							<a href="<?php the_permalink(); ?>">
								<div class="widget-img">
									<?php
									if ( has_post_thumbnail() ) {
										the_post_thumbnail( 'thumbnail' );
									}
									?>
								</div>
								<div class="widget-text">
									<h4><?php the_title(); ?></h4>
									<p><?php echo esc_html( wp_trim_words( strip_tags( get_the_content() ), 16 ) ); ?></p>
									<span class="date"><?php echo esc_html( get_the_date( 'Y-m-d' ) ); ?></span>
								</div>
							</a>
						</li>
						<?php
					endwhile;
					wp_reset_postdata();
				else :
					?>
					<li>
						<a href="#">
							<div class="widget-img">
								<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-daily3.webp?raw=true" alt="Game Boy畫面上的俄羅斯方塊" loading="lazy">
							</div>
							<div class="widget-text">
								<h4>俄羅斯方塊的冷戰秘辛</h4>
								<p>這款簡單的遊戲差點引發外交危機...</p>
								<span class="date">2023-12-03</span>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="widget-img">
								<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-daily2.webp?raw=true" alt="魂斗羅選單" loading="lazy">
							</div>
							<div class="widget-text">
								<h4>上上下下左右左右BA</h4>
								<p>這串神秘代碼是如何成為流行文化的代名詞？</p>
								<span class="date">2023-12-02</span>
							</div>
						</a>
					</li>
					<li>
						<a href="#">
							<div class="widget-img">
								<img src="https://github.com/liouyuting112/static-sites-monorepo-1/blob/main/shared-assets/site1-daily1.webp?raw=true" alt="瑪利歐頭像" loading="lazy">
							</div>
							<div class="widget-text">
								<h4>為什麼瑪利歐要留鬍子？</h4>
								<p>其實不是因為帥，而是因為當年的解析度實在太低了。</p>
								<span class="date">2023-12-01</span>
							</div>
						</a>
					</li>
					<?php
				endif;
				?>
			</ul>
		</section>
	</aside>
</div>

<?php
get_footer();


