<?php
/**
 * Theme footer
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
    <footer>
        <p>&copy; <?php echo esc_html( date( 'Y' ) ); ?> 懷舊時光機 Retro Time Machine.</p>
    </footer>

    <?php wp_footer(); ?>
</body>
</html>


